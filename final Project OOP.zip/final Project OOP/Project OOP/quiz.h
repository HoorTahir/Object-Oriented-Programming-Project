//#include "MainScreen.h"
#include "endquiz.h"
#include <iostream>
#include <conio.h>
#include <string>
#include <fstream>
#include <msclr\marshal_cppstd.h>
using namespace std;

#pragma once




namespace ProjectOOP {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for quiz
	/// </summary>
	public ref class quiz : public System::Windows::Forms::Form
	{

		int c = 0;
		int ca = 0;
		int score = 0;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::PictureBox^  pictureBox1;

	private: System::Windows::Forms::Label^  label2;
			 

	public:
		quiz(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}


	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~quiz()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected:
	private: System::Windows::Forms::Label^  question;
	private: System::Windows::Forms::CheckBox^  option1;
	private: System::Windows::Forms::CheckBox^  option2;
	private: System::Windows::Forms::CheckBox^  option3;
	private: System::Windows::Forms::CheckBox^  option4;
	private: System::Windows::Forms::Button^  start;

	private: System::Windows::Forms::Button^  submit;
	private: System::Windows::Forms::Button^  button3;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>

		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(quiz::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->question = (gcnew System::Windows::Forms::Label());
			this->option1 = (gcnew System::Windows::Forms::CheckBox());
			this->option2 = (gcnew System::Windows::Forms::CheckBox());
			this->option3 = (gcnew System::Windows::Forms::CheckBox());
			this->option4 = (gcnew System::Windows::Forms::CheckBox());
			this->start = (gcnew System::Windows::Forms::Button());
			this->submit = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(77, 49);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(65, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Question";
			// 
			// question
			// 
			this->question->AutoSize = true;
			this->question->Location = System::Drawing::Point(107, 81);
			this->question->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->question->Name = L"question";
			this->question->Size = System::Drawing::Size(0, 17);
			this->question->TabIndex = 1;
			this->question->Click += gcnew System::EventHandler(this, &quiz::question_Click);
			// 
			// option1
			// 
			this->option1->AutoSize = true;
			this->option1->Location = System::Drawing::Point(81, 192);
			this->option1->Margin = System::Windows::Forms::Padding(4);
			this->option1->Name = L"option1";
			this->option1->Size = System::Drawing::Size(18, 17);
			this->option1->TabIndex = 2;
			this->option1->UseVisualStyleBackColor = true;
			this->option1->CheckedChanged += gcnew System::EventHandler(this, &quiz::option1_CheckedChanged);
			// 
			// option2
			// 
			this->option2->AutoSize = true;
			this->option2->Location = System::Drawing::Point(275, 192);
			this->option2->Margin = System::Windows::Forms::Padding(4);
			this->option2->Name = L"option2";
			this->option2->Size = System::Drawing::Size(18, 17);
			this->option2->TabIndex = 3;
			this->option2->UseVisualStyleBackColor = true;
			this->option2->CheckedChanged += gcnew System::EventHandler(this, &quiz::option2_CheckedChanged);
			// 
			// option3
			// 
			this->option3->AutoSize = true;
			this->option3->Location = System::Drawing::Point(81, 254);
			this->option3->Margin = System::Windows::Forms::Padding(4);
			this->option3->Name = L"option3";
			this->option3->Size = System::Drawing::Size(18, 17);
			this->option3->TabIndex = 4;
			this->option3->UseVisualStyleBackColor = true;
			this->option3->CheckedChanged += gcnew System::EventHandler(this, &quiz::option3_CheckedChanged);
			// 
			// option4
			// 
			this->option4->AutoSize = true;
			this->option4->Location = System::Drawing::Point(275, 254);
			this->option4->Margin = System::Windows::Forms::Padding(4);
			this->option4->Name = L"option4";
			this->option4->Size = System::Drawing::Size(18, 17);
			this->option4->TabIndex = 5;
			this->option4->UseVisualStyleBackColor = true;
			this->option4->CheckedChanged += gcnew System::EventHandler(this, &quiz::option4_CheckedChanged);
			// 
			// start
			// 
			this->start->Location = System::Drawing::Point(81, 335);
			this->start->Margin = System::Windows::Forms::Padding(4);
			this->start->Name = L"start";
			this->start->Size = System::Drawing::Size(100, 28);
			this->start->TabIndex = 6;
			this->start->Text = L"Start";
			this->start->UseVisualStyleBackColor = true;
			this->start->Click += gcnew System::EventHandler(this, &quiz::start_Click);
			// 
			// submit
			// 
			this->submit->Location = System::Drawing::Point(275, 334);
			this->submit->Margin = System::Windows::Forms::Padding(4);
			this->submit->Name = L"submit";
			this->submit->Size = System::Drawing::Size(100, 28);
			this->submit->TabIndex = 7;
			this->submit->Text = L"Submit";
			this->submit->UseVisualStyleBackColor = true;
			this->submit->Click += gcnew System::EventHandler(this, &quiz::submit_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(438, 335);
			this->button3->Margin = System::Windows::Forms::Padding(4);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(100, 28);
			this->button3->TabIndex = 8;
			this->button3->Text = L"Close";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &quiz::button3_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(466, 386);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(16, 17);
			this->label2->TabIndex = 9;
			this->label2->Text = L"0";
			this->label2->Click += gcnew System::EventHandler(this, &quiz::label2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(377, 386);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(83, 17);
			this->label3->TabIndex = 10;
			this->label3->Text = L"Your Score:";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(520, 138);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(159, 166);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 11;
			this->pictureBox1->TabStop = false;
			// 
			// quiz
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(728, 426);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->submit);
			this->Controls->Add(this->start);
			this->Controls->Add(this->option4);
			this->Controls->Add(this->option3);
			this->Controls->Add(this->option2);
			this->Controls->Add(this->option1);
			this->Controls->Add(this->question);
			this->Controls->Add(this->label1);
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"quiz";
			this->Text = L"quiz";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}

#pragma endregion
	private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) 
	{
				 Close();
	}
private: System::Void start_Click(System::Object^  sender, System::EventArgs^  e)
{
			 c = c + 1;

			 this->option1->Checked = false;
			 this->option2->Checked = false;
			 this->option3->Checked = false;
			 this->option4->Checked = false;
			 
			 string que;
			 string op1;
			 string op2;
			 string op3;
			 string op4;
			 fstream fileq("GenKnowQ.txt");

			 getline(fileq, que);	
			 this->question->Text = gcnew String(que.c_str());
			 getline(fileq, op1);
			 this->option1->Text = gcnew String(op1.c_str());
			 getline(fileq, op2);
			 this->option2->Text = gcnew String(op2.c_str());
			 getline(fileq, op3);
			 this->option3->Text = gcnew String(op3.c_str());
			 getline(fileq, op4);
			 this->option4->Text = gcnew String(op4.c_str());
}
private: System::Void option1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) 
{
			 this->option2->Checked = false;
			 this->option3->Checked = false;
			 this->option4->Checked = false;
}
private: System::Void option2_CheckedChanged(System::Object^  sender, System::EventArgs^  e) 
{
			 this->option1->Checked = false;
			 this->option3->Checked = false;
			 this->option4->Checked = false;
}
private: System::Void option3_CheckedChanged(System::Object^  sender, System::EventArgs^  e) 
{
			 this->option1->Checked = false;
			 this->option2->Checked = false;
			 this->option4->Checked = false;
}
private: System::Void option4_CheckedChanged(System::Object^  sender, System::EventArgs^  e) 
{
			 this->option1->Checked = false;
			 this->option2->Checked = false;
			 this->option3->Checked = false;
}
private: System::Void submit_Click(System::Object^  sender, System::EventArgs^  e) 
{
			
			 this->option1->Checked= false;
			 this->option2->Checked = false;
			 this->option3->Checked = false;
			 this->option4->Checked = false;

			 

			 fstream filea("GenKnowA.txt");
			 fstream fileq("GenKnowQ.txt");
			 
			 string a;

			 string que;
			 string op1;
			 string op2;
			 string op3;
			 string op4;

			 for (int i = 0; i < c*5; i++)
			 {
				 getline(fileq, que);
			 }
			 if (ca != 0)
			 {
				 for (int i = 0; i < ca; i++)
				 {
					 getline(filea, a);
				 }
			 }

			 
			 
			 filea>>a;
			 if ((a == "1") && (option1->Checked))
			 {
				 score++;
			 }
			 else if ((a == "2") && (this->option2->Checked))
			 {
				 score++;
			 }
			 else if ((a == "3") && (this->option3->Checked))
			 {
				 score++;
			 }
			 else if ((a == "4") && (this->option4->Checked))
			 {
				 score++;
			 }
			 getline(fileq, que);
			 this->question->Text = gcnew String(que.c_str());
			 getline(fileq, op1);
			 this->option1->Text = gcnew String(op1.c_str());
			 getline(fileq, op2);
			 this->option2->Text = gcnew String(op2.c_str());
			 getline(fileq, op3);
			 this->option3->Text = gcnew String(op3.c_str());
			 getline(fileq, op4);
			 this->option4->Text = gcnew String(op4.c_str());
			 c++;
			 ca++;
			 this->label2->Text = System::Convert::ToString(score);

			 if (c == 10)
			 {
				 endquiz^ eq = gcnew endquiz();
				 eq->Show();
			 }
			 
}
private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void question_Click(System::Object^  sender, System::EventArgs^  e) {
}
};
}
