#include "hanglose.h"
#include "hangwon.h"
#include "iostream"
#include "conio.h"
#include "ctime"
#include <string>
#include <fstream>
#include <msclr\marshal_cppstd.h>
using namespace std;

#pragma once
string word;
string s;
int miss = 0;
int tri = 8;

namespace ProjectOOP {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for hangman
	/// </summary>
	public ref class hangman : public System::Windows::Forms::Form
	{
	public:
		hangman(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~hangman()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  guessWord;
	protected:
	private: System::Windows::Forms::Label^  stars;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  guessLetter;
	private: System::Windows::Forms::Label^  coIn;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  misses;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  tires;
	private: System::Windows::Forms::Button^  check;
	private: System::Windows::Forms::Button^  start;
	private: System::Windows::Forms::Button^  close;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::PictureBox^  pictureBox2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(hangman::typeid));
			this->guessWord = (gcnew System::Windows::Forms::Label());
			this->stars = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->guessLetter = (gcnew System::Windows::Forms::TextBox());
			this->coIn = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->misses = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->tires = (gcnew System::Windows::Forms::Label());
			this->check = (gcnew System::Windows::Forms::Button());
			this->start = (gcnew System::Windows::Forms::Button());
			this->close = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			this->SuspendLayout();
			// 
			// guessWord
			// 
			this->guessWord->AutoSize = true;
			this->guessWord->Location = System::Drawing::Point(126, 102);
			this->guessWord->Name = L"guessWord";
			this->guessWord->Size = System::Drawing::Size(42, 17);
			this->guessWord->TabIndex = 0;
			this->guessWord->Text = L"Word";
			// 
			// stars
			// 
			this->stars->AutoSize = true;
			this->stars->Location = System::Drawing::Point(251, 102);
			this->stars->Name = L"stars";
			this->stars->Size = System::Drawing::Size(33, 17);
			this->stars->TabIndex = 1;
			this->stars->Text = L"-----";
			this->stars->Click += gcnew System::EventHandler(this, &hangman::stars_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(103, 146);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(83, 17);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Enter Letter";
			// 
			// guessLetter
			// 
			this->guessLetter->Location = System::Drawing::Point(206, 140);
			this->guessLetter->Name = L"guessLetter";
			this->guessLetter->Size = System::Drawing::Size(133, 22);
			this->guessLetter->TabIndex = 3;
			this->guessLetter->TextChanged += gcnew System::EventHandler(this, &hangman::guessLetter_TextChanged);
			// 
			// coIn
			// 
			this->coIn->AutoSize = true;
			this->coIn->Location = System::Drawing::Point(332, 98);
			this->coIn->Name = L"coIn";
			this->coIn->Size = System::Drawing::Size(0, 17);
			this->coIn->TabIndex = 4;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(117, 227);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(51, 17);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Misses";
			// 
			// misses
			// 
			this->misses->AutoSize = true;
			this->misses->Location = System::Drawing::Point(261, 227);
			this->misses->Name = L"misses";
			this->misses->Size = System::Drawing::Size(16, 17);
			this->misses->TabIndex = 6;
			this->misses->Text = L"0";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(100, 285);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(68, 17);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Tries Left";
			// 
			// tires
			// 
			this->tires->AutoSize = true;
			this->tires->Location = System::Drawing::Point(261, 285);
			this->tires->Name = L"tires";
			this->tires->Size = System::Drawing::Size(16, 17);
			this->tires->TabIndex = 8;
			this->tires->Text = L"8";
			// 
			// check
			// 
			this->check->Location = System::Drawing::Point(236, 168);
			this->check->Name = L"check";
			this->check->Size = System::Drawing::Size(75, 23);
			this->check->TabIndex = 9;
			this->check->Text = L"OK";
			this->check->UseVisualStyleBackColor = true;
			this->check->Click += gcnew System::EventHandler(this, &hangman::check_Click);
			// 
			// start
			// 
			this->start->Location = System::Drawing::Point(93, 362);
			this->start->Name = L"start";
			this->start->Size = System::Drawing::Size(75, 23);
			this->start->TabIndex = 10;
			this->start->Text = L"Start";
			this->start->UseVisualStyleBackColor = true;
			this->start->Click += gcnew System::EventHandler(this, &hangman::start_Click);
			// 
			// close
			// 
			this->close->Location = System::Drawing::Point(236, 362);
			this->close->Name = L"close";
			this->close->Size = System::Drawing::Size(75, 23);
			this->close->TabIndex = 11;
			this->close->Text = L"Close";
			this->close->UseVisualStyleBackColor = true;
			this->close->Click += gcnew System::EventHandler(this, &hangman::close_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(339, 102);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(0, 17);
			this->label4->TabIndex = 12;
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(176, 12);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(351, 66);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 13;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &hangman::pictureBox1_Click);
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.BackgroundImage")));
			this->pictureBox2->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(407, 102);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(211, 275);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox2->TabIndex = 14;
			this->pictureBox2->TabStop = false;
			this->pictureBox2->Click += gcnew System::EventHandler(this, &hangman::pictureBox2_Click);
			// 
			// hangman
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(644, 439);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->close);
			this->Controls->Add(this->start);
			this->Controls->Add(this->check);
			this->Controls->Add(this->tires);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->misses);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->coIn);
			this->Controls->Add(this->guessLetter);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->stars);
			this->Controls->Add(this->guessWord);
			this->Name = L"hangman";
			this->Text = L"hangman";
			this->Load += gcnew System::EventHandler(this, &hangman::hangman_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void close_Click(System::Object^  sender, System::EventArgs^  e) 
	{
				 Close();
	}
		
private: System::Void start_Click(System::Object^  sender, System::EventArgs^  e) 
{
			/* int randomnum;
			 srand(time(0));
			 randomnum = (rand() % 5) + 1;*/

			 this->misses->Text = "0";
			 this->tires->Text = "8";
			
			 this->check->Enabled = true;

			 int x = rand() % 5;
			 
			 ifstream infile("Words.txt");
			 if (x != 0)
			 {
				 for (int i = 0; i < x; i++)
				 {
					 getline(infile, word);
				 }
			 }
			 else
			 {
				 getline(infile, word);
			 }
			 string stars = "";

			 /*String^ str2 = gcnew String(word.c_str());*/
			 
			 for (int i = 0; i < word.length(); i++)
			 {
				 stars += "-";
			 }
			 String^ str2 = gcnew String(stars.c_str());
			 this->stars->Text = str2;
			 s = stars;
}
private: System::Void guessLetter_TextChanged(System::Object^  sender, System::EventArgs^  e) 
{

}
private: System::Void check_Click(System::Object^  sender, System::EventArgs^  e) 
{
			 

			 String^ gl = this->guessLetter->Text;
			 bool match = false;
			 msclr::interop::marshal_context context;
			 string g = context.marshal_as<string>(guessLetter->Text);
			 
			 for (int i = 0; i < word.length(); i++)
			 {
				 if (g[0] == word[i])
				 {
					 s[i] = g[0];
					 match = true;
					 this->label4->Text = "Correct";
					 this->label4->ForeColor = System::Drawing::Color::Green;
				 }
				 
			 }

			 if (match == false)
			 {
				 miss++;
				 tri -= 1;
				 misses->Text = System::Convert::ToString(miss);
				 tires->Text = System::Convert::ToString(tri);
				 this->label4->Text = "Incorrect";
				 this->label4->ForeColor = System::Drawing::Color::Red;
			 }

			// this->misses->Text = String::Empty;
			

			 String^ str = gcnew String(s.c_str());
			 this->stars->Text = str;
			 this->guessLetter->Text = String::Empty;


			 if (tri == 0)
			 {
				 hanglose^ hl = gcnew hanglose();
				 this->check->Enabled = false;
				 hl->Show();
				 miss = 0;
				 tri = 8;
			 }


			 size_t found = s.find('-');
			 if (found == std::string::npos)
			 {
				 hangwon^ hw = gcnew hangwon();
				 hw->Show();
				 miss = 0;
				 tri = 8;
			 }
}
private: System::Void hangman_Load(System::Object^  sender, System::EventArgs^  e) 
{

}
private: System::Void stars_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void pictureBox1_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void pictureBox2_Click(System::Object^  sender, System::EventArgs^  e) {
}
};
}
