#include <iostream>
#include <fstream>
#include <msclr\marshal_cppstd.h>
using namespace std;

#pragma once

namespace ProjectOOP {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for dictionary
	/// </summary>
	public ref class dictionary : public System::Windows::Forms::Form
	{
	public:
		dictionary(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~dictionary()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:

	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  meaning;
	private: System::Windows::Forms::Label^  synonym;
	private: System::Windows::Forms::Label^  antonym;
	private: System::Windows::Forms::Label^  sentence;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::ListBox^  listBox1;
	private: System::Windows::Forms::PictureBox^  pictureBox1;






	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(dictionary::typeid));
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->meaning = (gcnew System::Windows::Forms::Label());
			this->synonym = (gcnew System::Windows::Forms::Label());
			this->antonym = (gcnew System::Windows::Forms::Label());
			this->sentence = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->listBox1 = (gcnew System::Windows::Forms::ListBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(133, 37);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(203, 22);
			this->textBox1->TabIndex = 2;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(404, 37);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 3;
			this->button1->Text = L"OK";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &dictionary::button1_Click);
			// 
			// meaning
			// 
			this->meaning->AutoSize = true;
			this->meaning->Location = System::Drawing::Point(179, 132);
			this->meaning->Name = L"meaning";
			this->meaning->Size = System::Drawing::Size(0, 17);
			this->meaning->TabIndex = 4;
			// 
			// synonym
			// 
			this->synonym->AutoSize = true;
			this->synonym->Location = System::Drawing::Point(179, 196);
			this->synonym->Name = L"synonym";
			this->synonym->Size = System::Drawing::Size(0, 17);
			this->synonym->TabIndex = 5;
			this->synonym->Click += gcnew System::EventHandler(this, &dictionary::synonym_Click);
			// 
			// antonym
			// 
			this->antonym->AutoSize = true;
			this->antonym->Location = System::Drawing::Point(179, 272);
			this->antonym->Name = L"antonym";
			this->antonym->Size = System::Drawing::Size(0, 17);
			this->antonym->TabIndex = 6;
			// 
			// sentence
			// 
			this->sentence->AutoSize = true;
			this->sentence->Location = System::Drawing::Point(179, 331);
			this->sentence->Name = L"sentence";
			this->sentence->Size = System::Drawing::Size(0, 17);
			this->sentence->TabIndex = 7;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(130, 109);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(66, 17);
			this->label1->TabIndex = 8;
			this->label1->Text = L"Meaning:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(130, 168);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(70, 17);
			this->label2->TabIndex = 9;
			this->label2->Text = L"Synonym:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(130, 232);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(67, 17);
			this->label3->TabIndex = 10;
			this->label3->Text = L"Antonym:";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(133, 302);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(72, 17);
			this->label4->TabIndex = 11;
			this->label4->Text = L"Sentance:";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(136, 77);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(0, 17);
			this->label5->TabIndex = 12;
			// 
			// listBox1
			// 
			this->listBox1->FormattingEnabled = true;
			this->listBox1->ItemHeight = 16;
			this->listBox1->Location = System::Drawing::Point(543, 37);
			this->listBox1->Name = L"listBox1";
			this->listBox1->Size = System::Drawing::Size(163, 196);
			this->listBox1->TabIndex = 13;
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(543, 239);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(163, 137);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 14;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &dictionary::pictureBox1_Click);
			// 
			// dictionary
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(805, 409);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->listBox1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->sentence);
			this->Controls->Add(this->antonym);
			this->Controls->Add(this->synonym);
			this->Controls->Add(this->meaning);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textBox1);
			this->Name = L"dictionary";
			this->Text = L"dictionary";
			this->Load += gcnew System::EventHandler(this, &dictionary::dictionary_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
	{
				 String^ word;
				 word = this->textBox1->Text;
				 fstream filed("dictionary.txt");
				 msclr::interop::marshal_context context;
				 string word1 = context.marshal_as<string>(word);
				 string fileword;
				 string aaaaa;
				 while (!filed.eof())
				 {
					 
					 getline(filed, fileword);
					 if (fileword == word1)
					 {
						 aaaaa = fileword;
						 this->label5->Text = "";
						 string mean;
						 string syn;
						 string ant;
						 string sen;
						 getline(filed, mean);
						 this->meaning->Text = gcnew String(mean.c_str());
						 getline(filed, syn);
						 this->synonym->Text = gcnew String(syn.c_str());
						 getline(filed, ant);
						 this->antonym->Text = gcnew String(ant.c_str());
						 getline(filed, sen);
						 this->sentence->Text = gcnew String(sen.c_str());
					 }
					 
				 }

				 if (aaaaa != word1)
				 {
					 this->label5->Text = "Sorry!! Word not found";
					 this->label5->ForeColor = System::Drawing::Color::Red;
					 this->meaning->Text = "---------";
					 this->synonym->Text = "---------";
					 this->antonym->Text = "---------";
					 this->sentence->Text = "---------";
				 }

	}
	private: System::Void synonym_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void dictionary_Load(System::Object^  sender, System::EventArgs^  e) 
{
			 fstream file("dictionary.txt");
			 while (!file.eof())
			 {
				 string a;
				 getline(file, a);
				 this->listBox1->Items->Add(gcnew String(a.c_str()));
				 for (int i = 0; i < 4; i++)
				 {
					 getline(file, a);
				 }
			 }
}
private: System::Void pictureBox1_Click(System::Object^  sender, System::EventArgs^  e) {
}
};
}
