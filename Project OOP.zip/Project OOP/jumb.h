#include <msclr\marshal_cppstd.h>
#include "jumpwon.h"
#include <iostream>
#include <conio.h>
#include <string>

using namespace std;
#pragma once

namespace ProjectOOP {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for jumb
	/// </summary>
	public ref class jumb : public System::Windows::Forms::Form
	{
	public:
		jumb(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~jumb()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  n1;
	protected:
	private: System::Windows::Forms::Label^  f1;
	private: System::Windows::Forms::Label^  o1;
	private: System::Windows::Forms::Label^  t1;
	private: System::Windows::Forms::Label^  oo1;
	private: System::Windows::Forms::Label^  ff1;
	private: System::Windows::Forms::Label^  i1;
	private: System::Windows::Forms::Label^  s1;
	private: System::Windows::Forms::Label^  h1;
	private: System::Windows::Forms::Label^  ooo1;
	private: System::Windows::Forms::Label^  d2;
	private: System::Windows::Forms::Label^  a2;
	private: System::Windows::Forms::Label^  n2;
	private: System::Windows::Forms::Label^  aa2;
	private: System::Windows::Forms::Label^  u2;
	private: System::Windows::Forms::Label^  o2;
	private: System::Windows::Forms::Label^  m2;
	private: System::Windows::Forms::Label^  c2;
	private: System::Windows::Forms::Label^  g2;
	private: System::Windows::Forms::Label^  h2;
	private: System::Windows::Forms::Label^  o3;
	private: System::Windows::Forms::Label^  b3;
	private: System::Windows::Forms::Label^  g3;
	private: System::Windows::Forms::Label^  s3;
	private: System::Windows::Forms::Label^  w3;
	private: System::Windows::Forms::Label^  r3;
	private: System::Windows::Forms::Label^  l3;
	private: System::Windows::Forms::Label^  bb3;
	private: System::Windows::Forms::Label^  a3;
	private: System::Windows::Forms::Label^  rr3;
	private: System::Windows::Forms::Label^  g4;
	private: System::Windows::Forms::Label^  u4;
	private: System::Windows::Forms::Label^  i4;
	private: System::Windows::Forms::Label^  h4;
	private: System::Windows::Forms::Label^  f4;
	private: System::Windows::Forms::Label^  e4;
	private: System::Windows::Forms::Label^  t4;
	private: System::Windows::Forms::Label^  o4;
	private: System::Windows::Forms::Label^  oo4;
	private: System::Windows::Forms::Label^  tt4;
	private: System::Windows::Forms::Label^  o5;
	private: System::Windows::Forms::Label^  n5;
	private: System::Windows::Forms::Label^  r5;
	private: System::Windows::Forms::Label^  f5;
	private: System::Windows::Forms::Label^  d5;
	private: System::Windows::Forms::Label^  b5;
	private: System::Windows::Forms::Label^  q5;
	private: System::Windows::Forms::Label^  l5;
	private: System::Windows::Forms::Label^  p5;
	private: System::Windows::Forms::Label^  rr5;
	private: System::Windows::Forms::Label^  m6;
	private: System::Windows::Forms::Label^  n6;
	private: System::Windows::Forms::Label^  a6;
	private: System::Windows::Forms::Label^  mm6;
	private: System::Windows::Forms::Label^  o6;
	private: System::Windows::Forms::Label^  u6;
	private: System::Windows::Forms::Label^  s6;
	private: System::Windows::Forms::Label^  e6;
	private: System::Windows::Forms::Label^  ee6;
	private: System::Windows::Forms::Label^  oo6;
	private: System::Windows::Forms::Label^  h7;
	private: System::Windows::Forms::Label^  y7;
	private: System::Windows::Forms::Label^  f7;
	private: System::Windows::Forms::Label^  o7;
	private: System::Windows::Forms::Label^  m7;
	private: System::Windows::Forms::Label^  oo7;
	private: System::Windows::Forms::Label^  n7;
	private: System::Windows::Forms::Label^  k7;
	private: System::Windows::Forms::Label^  e7;
	private: System::Windows::Forms::Label^  yy7;
	private: System::Windows::Forms::Label^  l8;
	private: System::Windows::Forms::Label^  n8;
	private: System::Windows::Forms::Label^  f8;
	private: System::Windows::Forms::Label^  g8;
	private: System::Windows::Forms::Label^  i8;
	private: System::Windows::Forms::Label^  a8;
	private: System::Windows::Forms::Label^  x8;
	private: System::Windows::Forms::Label^  nn8;
	private: System::Windows::Forms::Label^  m8;
	private: System::Windows::Forms::Label^  z8;
	private: System::Windows::Forms::Label^  y9;
	private: System::Windows::Forms::Label^  h9;
	private: System::Windows::Forms::Label^  e9;
	private: System::Windows::Forms::Label^  o9;
	private: System::Windows::Forms::Label^  s9;
	private: System::Windows::Forms::Label^  t9;
	private: System::Windows::Forms::Label^  r9;
	private: System::Windows::Forms::Label^  i9;
	private: System::Windows::Forms::Label^  c9;
	private: System::Windows::Forms::Label^  hh9;
	private: System::Windows::Forms::Label^  r10;
	private: System::Windows::Forms::Label^  e10;
	private: System::Windows::Forms::Label^  d10;
	private: System::Windows::Forms::Label^  u10;
	private: System::Windows::Forms::Label^  c10;
	private: System::Windows::Forms::Label^  k10;
	private: System::Windows::Forms::Label^  m10;
	private: System::Windows::Forms::Label^  o10;
	private: System::Windows::Forms::Label^  uu10;
	private: System::Windows::Forms::Label^  l10;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label10;
private: System::Windows::Forms::Label^  wo1;

private: System::Windows::Forms::Label^  wo2;
private: System::Windows::Forms::Label^  wo3;
private: System::Windows::Forms::Label^  wo4;
private: System::Windows::Forms::Label^  wo5;
private: System::Windows::Forms::Label^  wo6;
private: System::Windows::Forms::Label^  wo7;
private: System::Windows::Forms::Label^  wo8;
private: System::Windows::Forms::Label^  wo9;
private: System::Windows::Forms::Label^  wo10;













	private: System::Windows::Forms::Button^  close;
private: System::Windows::Forms::Label^  ci;
private: System::Windows::Forms::PictureBox^  pictureBox1;
private: System::Windows::Forms::PictureBox^  pictureBox2;












	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(jumb::typeid));
			this->n1 = (gcnew System::Windows::Forms::Label());
			this->f1 = (gcnew System::Windows::Forms::Label());
			this->o1 = (gcnew System::Windows::Forms::Label());
			this->t1 = (gcnew System::Windows::Forms::Label());
			this->oo1 = (gcnew System::Windows::Forms::Label());
			this->ff1 = (gcnew System::Windows::Forms::Label());
			this->i1 = (gcnew System::Windows::Forms::Label());
			this->s1 = (gcnew System::Windows::Forms::Label());
			this->h1 = (gcnew System::Windows::Forms::Label());
			this->ooo1 = (gcnew System::Windows::Forms::Label());
			this->d2 = (gcnew System::Windows::Forms::Label());
			this->a2 = (gcnew System::Windows::Forms::Label());
			this->n2 = (gcnew System::Windows::Forms::Label());
			this->aa2 = (gcnew System::Windows::Forms::Label());
			this->u2 = (gcnew System::Windows::Forms::Label());
			this->o2 = (gcnew System::Windows::Forms::Label());
			this->m2 = (gcnew System::Windows::Forms::Label());
			this->c2 = (gcnew System::Windows::Forms::Label());
			this->g2 = (gcnew System::Windows::Forms::Label());
			this->h2 = (gcnew System::Windows::Forms::Label());
			this->o3 = (gcnew System::Windows::Forms::Label());
			this->b3 = (gcnew System::Windows::Forms::Label());
			this->g3 = (gcnew System::Windows::Forms::Label());
			this->s3 = (gcnew System::Windows::Forms::Label());
			this->w3 = (gcnew System::Windows::Forms::Label());
			this->r3 = (gcnew System::Windows::Forms::Label());
			this->l3 = (gcnew System::Windows::Forms::Label());
			this->bb3 = (gcnew System::Windows::Forms::Label());
			this->a3 = (gcnew System::Windows::Forms::Label());
			this->rr3 = (gcnew System::Windows::Forms::Label());
			this->g4 = (gcnew System::Windows::Forms::Label());
			this->u4 = (gcnew System::Windows::Forms::Label());
			this->i4 = (gcnew System::Windows::Forms::Label());
			this->h4 = (gcnew System::Windows::Forms::Label());
			this->f4 = (gcnew System::Windows::Forms::Label());
			this->e4 = (gcnew System::Windows::Forms::Label());
			this->t4 = (gcnew System::Windows::Forms::Label());
			this->o4 = (gcnew System::Windows::Forms::Label());
			this->oo4 = (gcnew System::Windows::Forms::Label());
			this->tt4 = (gcnew System::Windows::Forms::Label());
			this->o5 = (gcnew System::Windows::Forms::Label());
			this->n5 = (gcnew System::Windows::Forms::Label());
			this->r5 = (gcnew System::Windows::Forms::Label());
			this->f5 = (gcnew System::Windows::Forms::Label());
			this->d5 = (gcnew System::Windows::Forms::Label());
			this->b5 = (gcnew System::Windows::Forms::Label());
			this->q5 = (gcnew System::Windows::Forms::Label());
			this->l5 = (gcnew System::Windows::Forms::Label());
			this->p5 = (gcnew System::Windows::Forms::Label());
			this->rr5 = (gcnew System::Windows::Forms::Label());
			this->m6 = (gcnew System::Windows::Forms::Label());
			this->n6 = (gcnew System::Windows::Forms::Label());
			this->a6 = (gcnew System::Windows::Forms::Label());
			this->mm6 = (gcnew System::Windows::Forms::Label());
			this->o6 = (gcnew System::Windows::Forms::Label());
			this->u6 = (gcnew System::Windows::Forms::Label());
			this->s6 = (gcnew System::Windows::Forms::Label());
			this->e6 = (gcnew System::Windows::Forms::Label());
			this->ee6 = (gcnew System::Windows::Forms::Label());
			this->oo6 = (gcnew System::Windows::Forms::Label());
			this->h7 = (gcnew System::Windows::Forms::Label());
			this->y7 = (gcnew System::Windows::Forms::Label());
			this->f7 = (gcnew System::Windows::Forms::Label());
			this->o7 = (gcnew System::Windows::Forms::Label());
			this->m7 = (gcnew System::Windows::Forms::Label());
			this->oo7 = (gcnew System::Windows::Forms::Label());
			this->n7 = (gcnew System::Windows::Forms::Label());
			this->k7 = (gcnew System::Windows::Forms::Label());
			this->e7 = (gcnew System::Windows::Forms::Label());
			this->yy7 = (gcnew System::Windows::Forms::Label());
			this->l8 = (gcnew System::Windows::Forms::Label());
			this->n8 = (gcnew System::Windows::Forms::Label());
			this->f8 = (gcnew System::Windows::Forms::Label());
			this->g8 = (gcnew System::Windows::Forms::Label());
			this->i8 = (gcnew System::Windows::Forms::Label());
			this->a8 = (gcnew System::Windows::Forms::Label());
			this->x8 = (gcnew System::Windows::Forms::Label());
			this->nn8 = (gcnew System::Windows::Forms::Label());
			this->m8 = (gcnew System::Windows::Forms::Label());
			this->z8 = (gcnew System::Windows::Forms::Label());
			this->y9 = (gcnew System::Windows::Forms::Label());
			this->h9 = (gcnew System::Windows::Forms::Label());
			this->e9 = (gcnew System::Windows::Forms::Label());
			this->o9 = (gcnew System::Windows::Forms::Label());
			this->s9 = (gcnew System::Windows::Forms::Label());
			this->t9 = (gcnew System::Windows::Forms::Label());
			this->r9 = (gcnew System::Windows::Forms::Label());
			this->i9 = (gcnew System::Windows::Forms::Label());
			this->c9 = (gcnew System::Windows::Forms::Label());
			this->hh9 = (gcnew System::Windows::Forms::Label());
			this->r10 = (gcnew System::Windows::Forms::Label());
			this->e10 = (gcnew System::Windows::Forms::Label());
			this->d10 = (gcnew System::Windows::Forms::Label());
			this->u10 = (gcnew System::Windows::Forms::Label());
			this->c10 = (gcnew System::Windows::Forms::Label());
			this->k10 = (gcnew System::Windows::Forms::Label());
			this->m10 = (gcnew System::Windows::Forms::Label());
			this->o10 = (gcnew System::Windows::Forms::Label());
			this->uu10 = (gcnew System::Windows::Forms::Label());
			this->l10 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->wo1 = (gcnew System::Windows::Forms::Label());
			this->wo2 = (gcnew System::Windows::Forms::Label());
			this->wo3 = (gcnew System::Windows::Forms::Label());
			this->wo4 = (gcnew System::Windows::Forms::Label());
			this->wo5 = (gcnew System::Windows::Forms::Label());
			this->wo6 = (gcnew System::Windows::Forms::Label());
			this->wo7 = (gcnew System::Windows::Forms::Label());
			this->wo8 = (gcnew System::Windows::Forms::Label());
			this->wo9 = (gcnew System::Windows::Forms::Label());
			this->wo10 = (gcnew System::Windows::Forms::Label());
			this->close = (gcnew System::Windows::Forms::Button());
			this->ci = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			this->SuspendLayout();
			// 
			// n1
			// 
			this->n1->AutoSize = true;
			this->n1->BackColor = System::Drawing::SystemColors::Menu;
			this->n1->Location = System::Drawing::Point(64, 56);
			this->n1->Name = L"n1";
			this->n1->Size = System::Drawing::Size(18, 17);
			this->n1->TabIndex = 0;
			this->n1->Text = L"N";
			// 
			// f1
			// 
			this->f1->AutoSize = true;
			this->f1->BackColor = System::Drawing::SystemColors::Menu;
			this->f1->Location = System::Drawing::Point(88, 56);
			this->f1->Name = L"f1";
			this->f1->Size = System::Drawing::Size(16, 17);
			this->f1->TabIndex = 1;
			this->f1->Text = L"F";
			// 
			// o1
			// 
			this->o1->AutoSize = true;
			this->o1->BackColor = System::Drawing::SystemColors::Menu;
			this->o1->Location = System::Drawing::Point(110, 56);
			this->o1->Name = L"o1";
			this->o1->Size = System::Drawing::Size(19, 17);
			this->o1->TabIndex = 2;
			this->o1->Text = L"O";
			// 
			// t1
			// 
			this->t1->AutoSize = true;
			this->t1->BackColor = System::Drawing::SystemColors::Menu;
			this->t1->Location = System::Drawing::Point(135, 56);
			this->t1->Name = L"t1";
			this->t1->Size = System::Drawing::Size(17, 17);
			this->t1->TabIndex = 3;
			this->t1->Text = L"T";
			// 
			// oo1
			// 
			this->oo1->AutoSize = true;
			this->oo1->BackColor = System::Drawing::SystemColors::Menu;
			this->oo1->Location = System::Drawing::Point(158, 56);
			this->oo1->Name = L"oo1";
			this->oo1->Size = System::Drawing::Size(19, 17);
			this->oo1->TabIndex = 4;
			this->oo1->Text = L"O";
			// 
			// ff1
			// 
			this->ff1->AutoSize = true;
			this->ff1->BackColor = System::Drawing::SystemColors::Menu;
			this->ff1->Location = System::Drawing::Point(183, 56);
			this->ff1->Name = L"ff1";
			this->ff1->Size = System::Drawing::Size(16, 17);
			this->ff1->TabIndex = 5;
			this->ff1->Text = L"F";
			// 
			// i1
			// 
			this->i1->AutoSize = true;
			this->i1->BackColor = System::Drawing::SystemColors::Menu;
			this->i1->Location = System::Drawing::Point(205, 56);
			this->i1->Name = L"i1";
			this->i1->Size = System::Drawing::Size(11, 17);
			this->i1->TabIndex = 6;
			this->i1->Text = L"I";
			// 
			// s1
			// 
			this->s1->AutoSize = true;
			this->s1->BackColor = System::Drawing::SystemColors::Menu;
			this->s1->Location = System::Drawing::Point(222, 56);
			this->s1->Name = L"s1";
			this->s1->Size = System::Drawing::Size(17, 17);
			this->s1->TabIndex = 7;
			this->s1->Text = L"S";
			// 
			// h1
			// 
			this->h1->AutoSize = true;
			this->h1->BackColor = System::Drawing::SystemColors::Menu;
			this->h1->Location = System::Drawing::Point(245, 56);
			this->h1->Name = L"h1";
			this->h1->Size = System::Drawing::Size(18, 17);
			this->h1->TabIndex = 8;
			this->h1->Text = L"H";
			// 
			// ooo1
			// 
			this->ooo1->AutoSize = true;
			this->ooo1->BackColor = System::Drawing::SystemColors::Menu;
			this->ooo1->Location = System::Drawing::Point(266, 56);
			this->ooo1->Name = L"ooo1";
			this->ooo1->Size = System::Drawing::Size(19, 17);
			this->ooo1->TabIndex = 9;
			this->ooo1->Text = L"O";
			// 
			// d2
			// 
			this->d2->AutoSize = true;
			this->d2->BackColor = System::Drawing::SystemColors::Menu;
			this->d2->Location = System::Drawing::Point(64, 73);
			this->d2->Name = L"d2";
			this->d2->Size = System::Drawing::Size(18, 17);
			this->d2->TabIndex = 10;
			this->d2->Text = L"D";
			// 
			// a2
			// 
			this->a2->AutoSize = true;
			this->a2->BackColor = System::Drawing::SystemColors::Menu;
			this->a2->Location = System::Drawing::Point(87, 73);
			this->a2->Name = L"a2";
			this->a2->Size = System::Drawing::Size(17, 17);
			this->a2->TabIndex = 11;
			this->a2->Text = L"A";
			// 
			// n2
			// 
			this->n2->AutoSize = true;
			this->n2->BackColor = System::Drawing::SystemColors::Menu;
			this->n2->Location = System::Drawing::Point(111, 73);
			this->n2->Name = L"n2";
			this->n2->Size = System::Drawing::Size(18, 17);
			this->n2->TabIndex = 12;
			this->n2->Text = L"N";
			// 
			// aa2
			// 
			this->aa2->AutoSize = true;
			this->aa2->BackColor = System::Drawing::SystemColors::Menu;
			this->aa2->Location = System::Drawing::Point(135, 73);
			this->aa2->Name = L"aa2";
			this->aa2->Size = System::Drawing::Size(17, 17);
			this->aa2->TabIndex = 13;
			this->aa2->Text = L"A";
			// 
			// u2
			// 
			this->u2->AutoSize = true;
			this->u2->BackColor = System::Drawing::SystemColors::Menu;
			this->u2->Location = System::Drawing::Point(159, 73);
			this->u2->Name = L"u2";
			this->u2->Size = System::Drawing::Size(18, 17);
			this->u2->TabIndex = 14;
			this->u2->Text = L"U";
			// 
			// o2
			// 
			this->o2->AutoSize = true;
			this->o2->BackColor = System::Drawing::SystemColors::Menu;
			this->o2->Location = System::Drawing::Point(180, 73);
			this->o2->Name = L"o2";
			this->o2->Size = System::Drawing::Size(19, 17);
			this->o2->TabIndex = 15;
			this->o2->Text = L"O";
			// 
			// m2
			// 
			this->m2->AutoSize = true;
			this->m2->BackColor = System::Drawing::SystemColors::Menu;
			this->m2->Location = System::Drawing::Point(200, 73);
			this->m2->Name = L"m2";
			this->m2->Size = System::Drawing::Size(19, 17);
			this->m2->TabIndex = 16;
			this->m2->Text = L"M";
			// 
			// c2
			// 
			this->c2->AutoSize = true;
			this->c2->BackColor = System::Drawing::SystemColors::Menu;
			this->c2->Location = System::Drawing::Point(222, 73);
			this->c2->Name = L"c2";
			this->c2->Size = System::Drawing::Size(17, 17);
			this->c2->TabIndex = 17;
			this->c2->Text = L"C";
			// 
			// g2
			// 
			this->g2->AutoSize = true;
			this->g2->BackColor = System::Drawing::SystemColors::Menu;
			this->g2->Location = System::Drawing::Point(245, 73);
			this->g2->Name = L"g2";
			this->g2->Size = System::Drawing::Size(19, 17);
			this->g2->TabIndex = 18;
			this->g2->Text = L"G";
			// 
			// h2
			// 
			this->h2->AutoSize = true;
			this->h2->BackColor = System::Drawing::SystemColors::Menu;
			this->h2->Location = System::Drawing::Point(266, 73);
			this->h2->Name = L"h2";
			this->h2->Size = System::Drawing::Size(18, 17);
			this->h2->TabIndex = 19;
			this->h2->Text = L"H";
			// 
			// o3
			// 
			this->o3->AutoSize = true;
			this->o3->BackColor = System::Drawing::SystemColors::Menu;
			this->o3->Location = System::Drawing::Point(63, 90);
			this->o3->Name = L"o3";
			this->o3->Size = System::Drawing::Size(19, 17);
			this->o3->TabIndex = 20;
			this->o3->Text = L"O";
			// 
			// b3
			// 
			this->b3->AutoSize = true;
			this->b3->BackColor = System::Drawing::SystemColors::Menu;
			this->b3->Location = System::Drawing::Point(87, 90);
			this->b3->Name = L"b3";
			this->b3->Size = System::Drawing::Size(17, 17);
			this->b3->TabIndex = 21;
			this->b3->Text = L"B";
			// 
			// g3
			// 
			this->g3->AutoSize = true;
			this->g3->BackColor = System::Drawing::SystemColors::Menu;
			this->g3->Location = System::Drawing::Point(110, 90);
			this->g3->Name = L"g3";
			this->g3->Size = System::Drawing::Size(19, 17);
			this->g3->TabIndex = 22;
			this->g3->Text = L"G";
			// 
			// s3
			// 
			this->s3->AutoSize = true;
			this->s3->BackColor = System::Drawing::SystemColors::Menu;
			this->s3->Location = System::Drawing::Point(135, 90);
			this->s3->Name = L"s3";
			this->s3->Size = System::Drawing::Size(17, 17);
			this->s3->TabIndex = 23;
			this->s3->Text = L"S";
			// 
			// w3
			// 
			this->w3->AutoSize = true;
			this->w3->BackColor = System::Drawing::SystemColors::Menu;
			this->w3->Location = System::Drawing::Point(156, 90);
			this->w3->Name = L"w3";
			this->w3->Size = System::Drawing::Size(21, 17);
			this->w3->TabIndex = 24;
			this->w3->Text = L"W";
			// 
			// r3
			// 
			this->r3->AutoSize = true;
			this->r3->BackColor = System::Drawing::SystemColors::Menu;
			this->r3->Location = System::Drawing::Point(181, 90);
			this->r3->Name = L"r3";
			this->r3->Size = System::Drawing::Size(18, 17);
			this->r3->TabIndex = 25;
			this->r3->Text = L"R";
			// 
			// l3
			// 
			this->l3->AutoSize = true;
			this->l3->BackColor = System::Drawing::SystemColors::Menu;
			this->l3->Location = System::Drawing::Point(203, 90);
			this->l3->Name = L"l3";
			this->l3->Size = System::Drawing::Size(16, 17);
			this->l3->TabIndex = 26;
			this->l3->Text = L"L";
			// 
			// bb3
			// 
			this->bb3->AutoSize = true;
			this->bb3->BackColor = System::Drawing::SystemColors::Menu;
			this->bb3->Location = System::Drawing::Point(222, 90);
			this->bb3->Name = L"bb3";
			this->bb3->Size = System::Drawing::Size(17, 17);
			this->bb3->TabIndex = 27;
			this->bb3->Text = L"B";
			// 
			// a3
			// 
			this->a3->AutoSize = true;
			this->a3->BackColor = System::Drawing::SystemColors::Menu;
			this->a3->Location = System::Drawing::Point(245, 90);
			this->a3->Name = L"a3";
			this->a3->Size = System::Drawing::Size(17, 17);
			this->a3->TabIndex = 28;
			this->a3->Text = L"A";
			// 
			// rr3
			// 
			this->rr3->AutoSize = true;
			this->rr3->BackColor = System::Drawing::SystemColors::Menu;
			this->rr3->Location = System::Drawing::Point(267, 90);
			this->rr3->Name = L"rr3";
			this->rr3->Size = System::Drawing::Size(18, 17);
			this->rr3->TabIndex = 29;
			this->rr3->Text = L"R";
			this->rr3->Click += gcnew System::EventHandler(this, &jumb::label10_Click);
			// 
			// g4
			// 
			this->g4->AutoSize = true;
			this->g4->BackColor = System::Drawing::SystemColors::Menu;
			this->g4->Location = System::Drawing::Point(62, 107);
			this->g4->Name = L"g4";
			this->g4->Size = System::Drawing::Size(19, 17);
			this->g4->TabIndex = 30;
			this->g4->Text = L"G";
			this->g4->Click += gcnew System::EventHandler(this, &jumb::label1_Click);
			// 
			// u4
			// 
			this->u4->AutoSize = true;
			this->u4->BackColor = System::Drawing::SystemColors::Menu;
			this->u4->Location = System::Drawing::Point(86, 107);
			this->u4->Name = L"u4";
			this->u4->Size = System::Drawing::Size(18, 17);
			this->u4->TabIndex = 31;
			this->u4->Text = L"U";
			// 
			// i4
			// 
			this->i4->AutoSize = true;
			this->i4->BackColor = System::Drawing::SystemColors::Menu;
			this->i4->Location = System::Drawing::Point(117, 107);
			this->i4->Name = L"i4";
			this->i4->Size = System::Drawing::Size(11, 17);
			this->i4->TabIndex = 32;
			this->i4->Text = L"I";
			// 
			// h4
			// 
			this->h4->AutoSize = true;
			this->h4->BackColor = System::Drawing::SystemColors::Menu;
			this->h4->Location = System::Drawing::Point(134, 107);
			this->h4->Name = L"h4";
			this->h4->Size = System::Drawing::Size(18, 17);
			this->h4->TabIndex = 33;
			this->h4->Text = L"H";
			// 
			// f4
			// 
			this->f4->AutoSize = true;
			this->f4->BackColor = System::Drawing::SystemColors::Menu;
			this->f4->Location = System::Drawing::Point(158, 107);
			this->f4->Name = L"f4";
			this->f4->Size = System::Drawing::Size(16, 17);
			this->f4->TabIndex = 34;
			this->f4->Text = L"F";
			// 
			// e4
			// 
			this->e4->AutoSize = true;
			this->e4->BackColor = System::Drawing::SystemColors::Menu;
			this->e4->Location = System::Drawing::Point(182, 107);
			this->e4->Name = L"e4";
			this->e4->Size = System::Drawing::Size(17, 17);
			this->e4->TabIndex = 35;
			this->e4->Text = L"E";
			// 
			// t4
			// 
			this->t4->AutoSize = true;
			this->t4->BackColor = System::Drawing::SystemColors::Menu;
			this->t4->Location = System::Drawing::Point(202, 107);
			this->t4->Name = L"t4";
			this->t4->Size = System::Drawing::Size(17, 17);
			this->t4->TabIndex = 36;
			this->t4->Text = L"T";
			// 
			// o4
			// 
			this->o4->AutoSize = true;
			this->o4->BackColor = System::Drawing::SystemColors::Menu;
			this->o4->Location = System::Drawing::Point(220, 107);
			this->o4->Name = L"o4";
			this->o4->Size = System::Drawing::Size(19, 17);
			this->o4->TabIndex = 37;
			this->o4->Text = L"O";
			// 
			// oo4
			// 
			this->oo4->AutoSize = true;
			this->oo4->BackColor = System::Drawing::SystemColors::Menu;
			this->oo4->Location = System::Drawing::Point(243, 107);
			this->oo4->Name = L"oo4";
			this->oo4->Size = System::Drawing::Size(19, 17);
			this->oo4->TabIndex = 38;
			this->oo4->Text = L"O";
			// 
			// tt4
			// 
			this->tt4->AutoSize = true;
			this->tt4->BackColor = System::Drawing::SystemColors::Menu;
			this->tt4->Location = System::Drawing::Point(267, 107);
			this->tt4->Name = L"tt4";
			this->tt4->Size = System::Drawing::Size(17, 17);
			this->tt4->TabIndex = 39;
			this->tt4->Text = L"T";
			// 
			// o5
			// 
			this->o5->AutoSize = true;
			this->o5->BackColor = System::Drawing::SystemColors::Menu;
			this->o5->Location = System::Drawing::Point(63, 124);
			this->o5->Name = L"o5";
			this->o5->Size = System::Drawing::Size(19, 17);
			this->o5->TabIndex = 40;
			this->o5->Text = L"O";
			// 
			// n5
			// 
			this->n5->AutoSize = true;
			this->n5->BackColor = System::Drawing::SystemColors::Menu;
			this->n5->Location = System::Drawing::Point(86, 124);
			this->n5->Name = L"n5";
			this->n5->Size = System::Drawing::Size(18, 17);
			this->n5->TabIndex = 41;
			this->n5->Text = L"N";
			// 
			// r5
			// 
			this->r5->AutoSize = true;
			this->r5->BackColor = System::Drawing::SystemColors::Menu;
			this->r5->Location = System::Drawing::Point(111, 124);
			this->r5->Name = L"r5";
			this->r5->Size = System::Drawing::Size(18, 17);
			this->r5->TabIndex = 42;
			this->r5->Text = L"R";
			// 
			// f5
			// 
			this->f5->AutoSize = true;
			this->f5->BackColor = System::Drawing::SystemColors::Menu;
			this->f5->Location = System::Drawing::Point(135, 124);
			this->f5->Name = L"f5";
			this->f5->Size = System::Drawing::Size(16, 17);
			this->f5->TabIndex = 43;
			this->f5->Text = L"F";
			// 
			// d5
			// 
			this->d5->AutoSize = true;
			this->d5->BackColor = System::Drawing::SystemColors::Menu;
			this->d5->Location = System::Drawing::Point(158, 124);
			this->d5->Name = L"d5";
			this->d5->Size = System::Drawing::Size(18, 17);
			this->d5->TabIndex = 44;
			this->d5->Text = L"D";
			// 
			// b5
			// 
			this->b5->AutoSize = true;
			this->b5->BackColor = System::Drawing::SystemColors::Menu;
			this->b5->Location = System::Drawing::Point(180, 124);
			this->b5->Name = L"b5";
			this->b5->Size = System::Drawing::Size(17, 17);
			this->b5->TabIndex = 45;
			this->b5->Text = L"B";
			// 
			// q5
			// 
			this->q5->AutoSize = true;
			this->q5->BackColor = System::Drawing::SystemColors::Menu;
			this->q5->Location = System::Drawing::Point(202, 124);
			this->q5->Name = L"q5";
			this->q5->Size = System::Drawing::Size(19, 17);
			this->q5->TabIndex = 46;
			this->q5->Text = L"Q";
			// 
			// l5
			// 
			this->l5->AutoSize = true;
			this->l5->BackColor = System::Drawing::SystemColors::Menu;
			this->l5->Location = System::Drawing::Point(222, 124);
			this->l5->Name = L"l5";
			this->l5->Size = System::Drawing::Size(16, 17);
			this->l5->TabIndex = 47;
			this->l5->Text = L"L";
			// 
			// p5
			// 
			this->p5->AutoSize = true;
			this->p5->BackColor = System::Drawing::SystemColors::Menu;
			this->p5->Location = System::Drawing::Point(245, 124);
			this->p5->Name = L"p5";
			this->p5->Size = System::Drawing::Size(17, 17);
			this->p5->TabIndex = 48;
			this->p5->Text = L"P";
			// 
			// rr5
			// 
			this->rr5->AutoSize = true;
			this->rr5->BackColor = System::Drawing::SystemColors::Menu;
			this->rr5->Location = System::Drawing::Point(267, 124);
			this->rr5->Name = L"rr5";
			this->rr5->Size = System::Drawing::Size(18, 17);
			this->rr5->TabIndex = 49;
			this->rr5->Text = L"R";
			// 
			// m6
			// 
			this->m6->AutoSize = true;
			this->m6->BackColor = System::Drawing::SystemColors::Menu;
			this->m6->Location = System::Drawing::Point(63, 141);
			this->m6->Name = L"m6";
			this->m6->Size = System::Drawing::Size(19, 17);
			this->m6->TabIndex = 50;
			this->m6->Text = L"M";
			// 
			// n6
			// 
			this->n6->AutoSize = true;
			this->n6->BackColor = System::Drawing::SystemColors::Menu;
			this->n6->Location = System::Drawing::Point(86, 141);
			this->n6->Name = L"n6";
			this->n6->Size = System::Drawing::Size(18, 17);
			this->n6->TabIndex = 51;
			this->n6->Text = L"N";
			// 
			// a6
			// 
			this->a6->AutoSize = true;
			this->a6->BackColor = System::Drawing::SystemColors::Menu;
			this->a6->Location = System::Drawing::Point(110, 141);
			this->a6->Name = L"a6";
			this->a6->Size = System::Drawing::Size(17, 17);
			this->a6->TabIndex = 52;
			this->a6->Text = L"A";
			// 
			// mm6
			// 
			this->mm6->AutoSize = true;
			this->mm6->BackColor = System::Drawing::SystemColors::Menu;
			this->mm6->Location = System::Drawing::Point(132, 141);
			this->mm6->Name = L"mm6";
			this->mm6->Size = System::Drawing::Size(19, 17);
			this->mm6->TabIndex = 53;
			this->mm6->Text = L"M";
			// 
			// o6
			// 
			this->o6->AutoSize = true;
			this->o6->BackColor = System::Drawing::SystemColors::Menu;
			this->o6->Location = System::Drawing::Point(157, 141);
			this->o6->Name = L"o6";
			this->o6->Size = System::Drawing::Size(19, 17);
			this->o6->TabIndex = 54;
			this->o6->Text = L"O";
			// 
			// u6
			// 
			this->u6->AutoSize = true;
			this->u6->BackColor = System::Drawing::SystemColors::Menu;
			this->u6->Location = System::Drawing::Point(181, 141);
			this->u6->Name = L"u6";
			this->u6->Size = System::Drawing::Size(18, 17);
			this->u6->TabIndex = 55;
			this->u6->Text = L"U";
			// 
			// s6
			// 
			this->s6->AutoSize = true;
			this->s6->BackColor = System::Drawing::SystemColors::Menu;
			this->s6->Location = System::Drawing::Point(202, 141);
			this->s6->Name = L"s6";
			this->s6->Size = System::Drawing::Size(17, 17);
			this->s6->TabIndex = 56;
			this->s6->Text = L"S";
			// 
			// e6
			// 
			this->e6->AutoSize = true;
			this->e6->BackColor = System::Drawing::SystemColors::Menu;
			this->e6->Location = System::Drawing::Point(222, 141);
			this->e6->Name = L"e6";
			this->e6->Size = System::Drawing::Size(17, 17);
			this->e6->TabIndex = 57;
			this->e6->Text = L"E";
			// 
			// ee6
			// 
			this->ee6->AutoSize = true;
			this->ee6->BackColor = System::Drawing::SystemColors::Menu;
			this->ee6->Location = System::Drawing::Point(245, 141);
			this->ee6->Name = L"ee6";
			this->ee6->Size = System::Drawing::Size(17, 17);
			this->ee6->TabIndex = 58;
			this->ee6->Text = L"E";
			// 
			// oo6
			// 
			this->oo6->AutoSize = true;
			this->oo6->BackColor = System::Drawing::SystemColors::Menu;
			this->oo6->Location = System::Drawing::Point(267, 141);
			this->oo6->Name = L"oo6";
			this->oo6->Size = System::Drawing::Size(19, 17);
			this->oo6->TabIndex = 59;
			this->oo6->Text = L"O";
			// 
			// h7
			// 
			this->h7->AutoSize = true;
			this->h7->BackColor = System::Drawing::SystemColors::Menu;
			this->h7->Location = System::Drawing::Point(63, 158);
			this->h7->Name = L"h7";
			this->h7->Size = System::Drawing::Size(18, 17);
			this->h7->TabIndex = 60;
			this->h7->Text = L"H";
			// 
			// y7
			// 
			this->y7->AutoSize = true;
			this->y7->BackColor = System::Drawing::SystemColors::Menu;
			this->y7->Location = System::Drawing::Point(86, 158);
			this->y7->Name = L"y7";
			this->y7->Size = System::Drawing::Size(17, 17);
			this->y7->TabIndex = 61;
			this->y7->Text = L"Y";
			// 
			// f7
			// 
			this->f7->AutoSize = true;
			this->f7->BackColor = System::Drawing::SystemColors::Menu;
			this->f7->Location = System::Drawing::Point(110, 158);
			this->f7->Name = L"f7";
			this->f7->Size = System::Drawing::Size(16, 17);
			this->f7->TabIndex = 62;
			this->f7->Text = L"F";
			// 
			// o7
			// 
			this->o7->AutoSize = true;
			this->o7->BackColor = System::Drawing::SystemColors::Menu;
			this->o7->Location = System::Drawing::Point(132, 158);
			this->o7->Name = L"o7";
			this->o7->Size = System::Drawing::Size(19, 17);
			this->o7->TabIndex = 63;
			this->o7->Text = L"O";
			// 
			// m7
			// 
			this->m7->AutoSize = true;
			this->m7->BackColor = System::Drawing::SystemColors::Menu;
			this->m7->Location = System::Drawing::Point(156, 158);
			this->m7->Name = L"m7";
			this->m7->Size = System::Drawing::Size(19, 17);
			this->m7->TabIndex = 64;
			this->m7->Text = L"M";
			// 
			// oo7
			// 
			this->oo7->AutoSize = true;
			this->oo7->BackColor = System::Drawing::SystemColors::Menu;
			this->oo7->Location = System::Drawing::Point(181, 158);
			this->oo7->Name = L"oo7";
			this->oo7->Size = System::Drawing::Size(19, 17);
			this->oo7->TabIndex = 65;
			this->oo7->Text = L"O";
			// 
			// n7
			// 
			this->n7->AutoSize = true;
			this->n7->BackColor = System::Drawing::SystemColors::Menu;
			this->n7->Location = System::Drawing::Point(202, 158);
			this->n7->Name = L"n7";
			this->n7->Size = System::Drawing::Size(18, 17);
			this->n7->TabIndex = 66;
			this->n7->Text = L"N";
			// 
			// k7
			// 
			this->k7->AutoSize = true;
			this->k7->BackColor = System::Drawing::SystemColors::Menu;
			this->k7->Location = System::Drawing::Point(222, 158);
			this->k7->Name = L"k7";
			this->k7->Size = System::Drawing::Size(17, 17);
			this->k7->TabIndex = 67;
			this->k7->Text = L"K";
			// 
			// e7
			// 
			this->e7->AutoSize = true;
			this->e7->BackColor = System::Drawing::SystemColors::Menu;
			this->e7->Location = System::Drawing::Point(245, 158);
			this->e7->Name = L"e7";
			this->e7->Size = System::Drawing::Size(17, 17);
			this->e7->TabIndex = 68;
			this->e7->Text = L"E";
			// 
			// yy7
			// 
			this->yy7->AutoSize = true;
			this->yy7->BackColor = System::Drawing::SystemColors::Menu;
			this->yy7->Location = System::Drawing::Point(268, 158);
			this->yy7->Name = L"yy7";
			this->yy7->Size = System::Drawing::Size(17, 17);
			this->yy7->TabIndex = 69;
			this->yy7->Text = L"Y";
			// 
			// l8
			// 
			this->l8->AutoSize = true;
			this->l8->BackColor = System::Drawing::SystemColors::Menu;
			this->l8->Location = System::Drawing::Point(66, 175);
			this->l8->Name = L"l8";
			this->l8->Size = System::Drawing::Size(16, 17);
			this->l8->TabIndex = 70;
			this->l8->Text = L"L";
			// 
			// n8
			// 
			this->n8->AutoSize = true;
			this->n8->BackColor = System::Drawing::SystemColors::Menu;
			this->n8->Location = System::Drawing::Point(84, 175);
			this->n8->Name = L"n8";
			this->n8->Size = System::Drawing::Size(18, 17);
			this->n8->TabIndex = 71;
			this->n8->Text = L"N";
			// 
			// f8
			// 
			this->f8->AutoSize = true;
			this->f8->BackColor = System::Drawing::SystemColors::Menu;
			this->f8->Location = System::Drawing::Point(108, 175);
			this->f8->Name = L"f8";
			this->f8->Size = System::Drawing::Size(16, 17);
			this->f8->TabIndex = 72;
			this->f8->Text = L"F";
			// 
			// g8
			// 
			this->g8->AutoSize = true;
			this->g8->BackColor = System::Drawing::SystemColors::Menu;
			this->g8->Location = System::Drawing::Point(130, 175);
			this->g8->Name = L"g8";
			this->g8->Size = System::Drawing::Size(19, 17);
			this->g8->TabIndex = 73;
			this->g8->Text = L"G";
			// 
			// i8
			// 
			this->i8->AutoSize = true;
			this->i8->BackColor = System::Drawing::SystemColors::Menu;
			this->i8->Location = System::Drawing::Point(159, 175);
			this->i8->Name = L"i8";
			this->i8->Size = System::Drawing::Size(11, 17);
			this->i8->TabIndex = 74;
			this->i8->Text = L"I";
			// 
			// a8
			// 
			this->a8->AutoSize = true;
			this->a8->BackColor = System::Drawing::SystemColors::Menu;
			this->a8->Location = System::Drawing::Point(181, 175);
			this->a8->Name = L"a8";
			this->a8->Size = System::Drawing::Size(17, 17);
			this->a8->TabIndex = 75;
			this->a8->Text = L"A";
			// 
			// x8
			// 
			this->x8->AutoSize = true;
			this->x8->BackColor = System::Drawing::SystemColors::Menu;
			this->x8->Location = System::Drawing::Point(204, 175);
			this->x8->Name = L"x8";
			this->x8->Size = System::Drawing::Size(17, 17);
			this->x8->TabIndex = 76;
			this->x8->Text = L"X";
			// 
			// nn8
			// 
			this->nn8->AutoSize = true;
			this->nn8->BackColor = System::Drawing::SystemColors::Menu;
			this->nn8->Location = System::Drawing::Point(222, 175);
			this->nn8->Name = L"nn8";
			this->nn8->Size = System::Drawing::Size(18, 17);
			this->nn8->TabIndex = 77;
			this->nn8->Text = L"N";
			// 
			// m8
			// 
			this->m8->AutoSize = true;
			this->m8->BackColor = System::Drawing::SystemColors::Menu;
			this->m8->Location = System::Drawing::Point(243, 175);
			this->m8->Name = L"m8";
			this->m8->Size = System::Drawing::Size(19, 17);
			this->m8->TabIndex = 78;
			this->m8->Text = L"M";
			// 
			// z8
			// 
			this->z8->AutoSize = true;
			this->z8->BackColor = System::Drawing::SystemColors::Menu;
			this->z8->Location = System::Drawing::Point(269, 175);
			this->z8->Name = L"z8";
			this->z8->Size = System::Drawing::Size(17, 17);
			this->z8->TabIndex = 79;
			this->z8->Text = L"Z";
			// 
			// y9
			// 
			this->y9->AutoSize = true;
			this->y9->BackColor = System::Drawing::SystemColors::Menu;
			this->y9->Location = System::Drawing::Point(63, 192);
			this->y9->Name = L"y9";
			this->y9->Size = System::Drawing::Size(17, 17);
			this->y9->TabIndex = 80;
			this->y9->Text = L"Y";
			// 
			// h9
			// 
			this->h9->AutoSize = true;
			this->h9->BackColor = System::Drawing::SystemColors::Menu;
			this->h9->Location = System::Drawing::Point(84, 192);
			this->h9->Name = L"h9";
			this->h9->Size = System::Drawing::Size(18, 17);
			this->h9->TabIndex = 81;
			this->h9->Text = L"H";
			// 
			// e9
			// 
			this->e9->AutoSize = true;
			this->e9->BackColor = System::Drawing::SystemColors::Menu;
			this->e9->Location = System::Drawing::Point(107, 192);
			this->e9->Name = L"e9";
			this->e9->Size = System::Drawing::Size(17, 17);
			this->e9->TabIndex = 82;
			this->e9->Text = L"E";
			// 
			// o9
			// 
			this->o9->AutoSize = true;
			this->o9->BackColor = System::Drawing::SystemColors::Menu;
			this->o9->Location = System::Drawing::Point(130, 192);
			this->o9->Name = L"o9";
			this->o9->Size = System::Drawing::Size(19, 17);
			this->o9->TabIndex = 83;
			this->o9->Text = L"O";
			// 
			// s9
			// 
			this->s9->AutoSize = true;
			this->s9->BackColor = System::Drawing::SystemColors::Menu;
			this->s9->Location = System::Drawing::Point(155, 192);
			this->s9->Name = L"s9";
			this->s9->Size = System::Drawing::Size(17, 17);
			this->s9->TabIndex = 84;
			this->s9->Text = L"S";
			// 
			// t9
			// 
			this->t9->AutoSize = true;
			this->t9->BackColor = System::Drawing::SystemColors::Menu;
			this->t9->Location = System::Drawing::Point(181, 192);
			this->t9->Name = L"t9";
			this->t9->Size = System::Drawing::Size(17, 17);
			this->t9->TabIndex = 85;
			this->t9->Text = L"T";
			// 
			// r9
			// 
			this->r9->AutoSize = true;
			this->r9->BackColor = System::Drawing::SystemColors::Menu;
			this->r9->Location = System::Drawing::Point(202, 192);
			this->r9->Name = L"r9";
			this->r9->Size = System::Drawing::Size(18, 17);
			this->r9->TabIndex = 86;
			this->r9->Text = L"R";
			// 
			// i9
			// 
			this->i9->AutoSize = true;
			this->i9->BackColor = System::Drawing::SystemColors::Menu;
			this->i9->Location = System::Drawing::Point(226, 192);
			this->i9->Name = L"i9";
			this->i9->Size = System::Drawing::Size(11, 17);
			this->i9->TabIndex = 87;
			this->i9->Text = L"I";
			// 
			// c9
			// 
			this->c9->AutoSize = true;
			this->c9->BackColor = System::Drawing::SystemColors::Menu;
			this->c9->Location = System::Drawing::Point(243, 192);
			this->c9->Name = L"c9";
			this->c9->Size = System::Drawing::Size(17, 17);
			this->c9->TabIndex = 88;
			this->c9->Text = L"C";
			// 
			// hh9
			// 
			this->hh9->AutoSize = true;
			this->hh9->BackColor = System::Drawing::SystemColors::Menu;
			this->hh9->Location = System::Drawing::Point(266, 192);
			this->hh9->Name = L"hh9";
			this->hh9->Size = System::Drawing::Size(18, 17);
			this->hh9->TabIndex = 89;
			this->hh9->Text = L"H";
			// 
			// r10
			// 
			this->r10->AutoSize = true;
			this->r10->BackColor = System::Drawing::SystemColors::Menu;
			this->r10->Location = System::Drawing::Point(62, 209);
			this->r10->Name = L"r10";
			this->r10->Size = System::Drawing::Size(18, 17);
			this->r10->TabIndex = 90;
			this->r10->Text = L"R";
			// 
			// e10
			// 
			this->e10->AutoSize = true;
			this->e10->BackColor = System::Drawing::SystemColors::Menu;
			this->e10->Location = System::Drawing::Point(84, 209);
			this->e10->Name = L"e10";
			this->e10->Size = System::Drawing::Size(17, 17);
			this->e10->TabIndex = 91;
			this->e10->Text = L"E";
			// 
			// d10
			// 
			this->d10->AutoSize = true;
			this->d10->BackColor = System::Drawing::SystemColors::Menu;
			this->d10->Location = System::Drawing::Point(107, 209);
			this->d10->Name = L"d10";
			this->d10->Size = System::Drawing::Size(18, 17);
			this->d10->TabIndex = 92;
			this->d10->Text = L"D";
			// 
			// u10
			// 
			this->u10->AutoSize = true;
			this->u10->BackColor = System::Drawing::SystemColors::Menu;
			this->u10->Location = System::Drawing::Point(131, 209);
			this->u10->Name = L"u10";
			this->u10->Size = System::Drawing::Size(18, 17);
			this->u10->TabIndex = 93;
			this->u10->Text = L"U";
			// 
			// c10
			// 
			this->c10->AutoSize = true;
			this->c10->BackColor = System::Drawing::SystemColors::Menu;
			this->c10->Location = System::Drawing::Point(156, 209);
			this->c10->Name = L"c10";
			this->c10->Size = System::Drawing::Size(17, 17);
			this->c10->TabIndex = 94;
			this->c10->Text = L"C";
			// 
			// k10
			// 
			this->k10->AutoSize = true;
			this->k10->BackColor = System::Drawing::SystemColors::Menu;
			this->k10->Location = System::Drawing::Point(179, 209);
			this->k10->Name = L"k10";
			this->k10->Size = System::Drawing::Size(17, 17);
			this->k10->TabIndex = 95;
			this->k10->Text = L"K";
			// 
			// m10
			// 
			this->m10->AutoSize = true;
			this->m10->BackColor = System::Drawing::SystemColors::Menu;
			this->m10->Location = System::Drawing::Point(201, 209);
			this->m10->Name = L"m10";
			this->m10->Size = System::Drawing::Size(19, 17);
			this->m10->TabIndex = 96;
			this->m10->Text = L"M";
			// 
			// o10
			// 
			this->o10->AutoSize = true;
			this->o10->BackColor = System::Drawing::SystemColors::Menu;
			this->o10->Location = System::Drawing::Point(222, 209);
			this->o10->Name = L"o10";
			this->o10->Size = System::Drawing::Size(19, 17);
			this->o10->TabIndex = 97;
			this->o10->Text = L"O";
			// 
			// uu10
			// 
			this->uu10->AutoSize = true;
			this->uu10->BackColor = System::Drawing::SystemColors::Menu;
			this->uu10->Location = System::Drawing::Point(244, 209);
			this->uu10->Name = L"uu10";
			this->uu10->Size = System::Drawing::Size(18, 17);
			this->uu10->TabIndex = 98;
			this->uu10->Text = L"U";
			// 
			// l10
			// 
			this->l10->AutoSize = true;
			this->l10->BackColor = System::Drawing::SystemColors::Menu;
			this->l10->Location = System::Drawing::Point(267, 209);
			this->l10->Name = L"l10";
			this->l10->Size = System::Drawing::Size(16, 17);
			this->l10->TabIndex = 99;
			this->l10->Text = L"L";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(100, 275);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(100, 22);
			this->textBox1->TabIndex = 100;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(211, 274);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 101;
			this->button1->Text = L"Enter";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &jumb::button1_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(60, 314);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(20, 17);
			this->label1->TabIndex = 102;
			this->label1->Text = L"1.";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(60, 341);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(20, 17);
			this->label2->TabIndex = 103;
			this->label2->Text = L"2.";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(60, 368);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(20, 17);
			this->label3->TabIndex = 104;
			this->label3->Text = L"3.";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(60, 396);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(20, 17);
			this->label4->TabIndex = 105;
			this->label4->Text = L"4.";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(60, 426);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(20, 17);
			this->label5->TabIndex = 106;
			this->label5->Text = L"5.";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(183, 314);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(20, 17);
			this->label6->TabIndex = 107;
			this->label6->Text = L"6.";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(183, 341);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(20, 17);
			this->label7->TabIndex = 108;
			this->label7->Text = L"7.";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(182, 370);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(20, 17);
			this->label8->TabIndex = 109;
			this->label8->Text = L"8.";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(183, 396);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(20, 17);
			this->label9->TabIndex = 110;
			this->label9->Text = L"9.";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(182, 426);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(28, 17);
			this->label10->TabIndex = 111;
			this->label10->Text = L"10.";
			// 
			// wo1
			// 
			this->wo1->AutoSize = true;
			this->wo1->Location = System::Drawing::Point(107, 314);
			this->wo1->Name = L"wo1";
			this->wo1->Size = System::Drawing::Size(33, 17);
			this->wo1->TabIndex = 112;
			this->wo1->Text = L"-----";
			// 
			// wo2
			// 
			this->wo2->AutoSize = true;
			this->wo2->Location = System::Drawing::Point(107, 341);
			this->wo2->Name = L"wo2";
			this->wo2->Size = System::Drawing::Size(33, 17);
			this->wo2->TabIndex = 113;
			this->wo2->Text = L"-----";
			this->wo2->Click += gcnew System::EventHandler(this, &jumb::wo2_Click);
			// 
			// wo3
			// 
			this->wo3->AutoSize = true;
			this->wo3->Location = System::Drawing::Point(107, 370);
			this->wo3->Name = L"wo3";
			this->wo3->Size = System::Drawing::Size(33, 17);
			this->wo3->TabIndex = 114;
			this->wo3->Text = L"-----";
			// 
			// wo4
			// 
			this->wo4->AutoSize = true;
			this->wo4->Location = System::Drawing::Point(107, 396);
			this->wo4->Name = L"wo4";
			this->wo4->Size = System::Drawing::Size(33, 17);
			this->wo4->TabIndex = 115;
			this->wo4->Text = L"-----";
			// 
			// wo5
			// 
			this->wo5->AutoSize = true;
			this->wo5->Location = System::Drawing::Point(107, 426);
			this->wo5->Name = L"wo5";
			this->wo5->Size = System::Drawing::Size(33, 17);
			this->wo5->TabIndex = 116;
			this->wo5->Text = L"-----";
			// 
			// wo6
			// 
			this->wo6->AutoSize = true;
			this->wo6->Location = System::Drawing::Point(229, 314);
			this->wo6->Name = L"wo6";
			this->wo6->Size = System::Drawing::Size(33, 17);
			this->wo6->TabIndex = 117;
			this->wo6->Text = L"-----";
			// 
			// wo7
			// 
			this->wo7->AutoSize = true;
			this->wo7->Location = System::Drawing::Point(229, 341);
			this->wo7->Name = L"wo7";
			this->wo7->Size = System::Drawing::Size(33, 17);
			this->wo7->TabIndex = 118;
			this->wo7->Text = L"-----";
			// 
			// wo8
			// 
			this->wo8->AutoSize = true;
			this->wo8->Location = System::Drawing::Point(229, 370);
			this->wo8->Name = L"wo8";
			this->wo8->Size = System::Drawing::Size(33, 17);
			this->wo8->TabIndex = 119;
			this->wo8->Text = L"-----";
			// 
			// wo9
			// 
			this->wo9->AutoSize = true;
			this->wo9->Location = System::Drawing::Point(227, 396);
			this->wo9->Name = L"wo9";
			this->wo9->Size = System::Drawing::Size(33, 17);
			this->wo9->TabIndex = 120;
			this->wo9->Text = L"-----";
			// 
			// wo10
			// 
			this->wo10->AutoSize = true;
			this->wo10->Location = System::Drawing::Point(226, 426);
			this->wo10->Name = L"wo10";
			this->wo10->Size = System::Drawing::Size(33, 17);
			this->wo10->TabIndex = 121;
			this->wo10->Text = L"-----";
			// 
			// close
			// 
			this->close->Location = System::Drawing::Point(141, 485);
			this->close->Name = L"close";
			this->close->Size = System::Drawing::Size(75, 23);
			this->close->TabIndex = 122;
			this->close->Text = L"Close";
			this->close->UseVisualStyleBackColor = true;
			this->close->Click += gcnew System::EventHandler(this, &jumb::close_Click);
			// 
			// ci
			// 
			this->ci->AutoSize = true;
			this->ci->Location = System::Drawing::Point(64, 246);
			this->ci->Name = L"ci";
			this->ci->Size = System::Drawing::Size(0, 17);
			this->ci->TabIndex = 123;
			// 
			// pictureBox1
			// 
			this->pictureBox1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(316, 73);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(281, 153);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 124;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &jumb::pictureBox1_Click);
			// 
			// pictureBox2
			// 
			this->pictureBox2->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(380, 275);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(160, 158);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox2->TabIndex = 125;
			this->pictureBox2->TabStop = false;
			// 
			// jumb
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(638, 581);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->ci);
			this->Controls->Add(this->close);
			this->Controls->Add(this->wo10);
			this->Controls->Add(this->wo9);
			this->Controls->Add(this->wo8);
			this->Controls->Add(this->wo7);
			this->Controls->Add(this->wo6);
			this->Controls->Add(this->wo5);
			this->Controls->Add(this->wo4);
			this->Controls->Add(this->wo3);
			this->Controls->Add(this->wo2);
			this->Controls->Add(this->wo1);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->l10);
			this->Controls->Add(this->uu10);
			this->Controls->Add(this->o10);
			this->Controls->Add(this->m10);
			this->Controls->Add(this->k10);
			this->Controls->Add(this->c10);
			this->Controls->Add(this->u10);
			this->Controls->Add(this->d10);
			this->Controls->Add(this->e10);
			this->Controls->Add(this->r10);
			this->Controls->Add(this->hh9);
			this->Controls->Add(this->c9);
			this->Controls->Add(this->i9);
			this->Controls->Add(this->r9);
			this->Controls->Add(this->t9);
			this->Controls->Add(this->s9);
			this->Controls->Add(this->o9);
			this->Controls->Add(this->e9);
			this->Controls->Add(this->h9);
			this->Controls->Add(this->y9);
			this->Controls->Add(this->z8);
			this->Controls->Add(this->m8);
			this->Controls->Add(this->nn8);
			this->Controls->Add(this->x8);
			this->Controls->Add(this->a8);
			this->Controls->Add(this->i8);
			this->Controls->Add(this->g8);
			this->Controls->Add(this->f8);
			this->Controls->Add(this->n8);
			this->Controls->Add(this->l8);
			this->Controls->Add(this->yy7);
			this->Controls->Add(this->e7);
			this->Controls->Add(this->k7);
			this->Controls->Add(this->n7);
			this->Controls->Add(this->oo7);
			this->Controls->Add(this->m7);
			this->Controls->Add(this->o7);
			this->Controls->Add(this->f7);
			this->Controls->Add(this->y7);
			this->Controls->Add(this->h7);
			this->Controls->Add(this->oo6);
			this->Controls->Add(this->ee6);
			this->Controls->Add(this->e6);
			this->Controls->Add(this->s6);
			this->Controls->Add(this->u6);
			this->Controls->Add(this->o6);
			this->Controls->Add(this->mm6);
			this->Controls->Add(this->a6);
			this->Controls->Add(this->n6);
			this->Controls->Add(this->m6);
			this->Controls->Add(this->rr5);
			this->Controls->Add(this->p5);
			this->Controls->Add(this->l5);
			this->Controls->Add(this->q5);
			this->Controls->Add(this->b5);
			this->Controls->Add(this->d5);
			this->Controls->Add(this->f5);
			this->Controls->Add(this->r5);
			this->Controls->Add(this->n5);
			this->Controls->Add(this->o5);
			this->Controls->Add(this->tt4);
			this->Controls->Add(this->oo4);
			this->Controls->Add(this->o4);
			this->Controls->Add(this->t4);
			this->Controls->Add(this->e4);
			this->Controls->Add(this->f4);
			this->Controls->Add(this->h4);
			this->Controls->Add(this->i4);
			this->Controls->Add(this->u4);
			this->Controls->Add(this->g4);
			this->Controls->Add(this->rr3);
			this->Controls->Add(this->a3);
			this->Controls->Add(this->bb3);
			this->Controls->Add(this->l3);
			this->Controls->Add(this->r3);
			this->Controls->Add(this->w3);
			this->Controls->Add(this->s3);
			this->Controls->Add(this->g3);
			this->Controls->Add(this->b3);
			this->Controls->Add(this->o3);
			this->Controls->Add(this->h2);
			this->Controls->Add(this->g2);
			this->Controls->Add(this->c2);
			this->Controls->Add(this->m2);
			this->Controls->Add(this->o2);
			this->Controls->Add(this->u2);
			this->Controls->Add(this->aa2);
			this->Controls->Add(this->n2);
			this->Controls->Add(this->a2);
			this->Controls->Add(this->d2);
			this->Controls->Add(this->ooo1);
			this->Controls->Add(this->h1);
			this->Controls->Add(this->s1);
			this->Controls->Add(this->i1);
			this->Controls->Add(this->ff1);
			this->Controls->Add(this->oo1);
			this->Controls->Add(this->t1);
			this->Controls->Add(this->o1);
			this->Controls->Add(this->f1);
			this->Controls->Add(this->n1);
			this->Name = L"jumb";
			this->Text = L"jumb";
			this->Load += gcnew System::EventHandler(this, &jumb::jumb_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void jumb_Load(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void label10_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void close_Click(System::Object^  sender, System::EventArgs^  e) 
{
			 Close();
}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e)
{
			 String^ word = this->textBox1->Text;
			 msclr::interop::marshal_context context;
			 string word1 = context.marshal_as<string>(word);

			 if (word1 == "turtle")
			 {
				 this->ci->Text = "Correct word!!";
				 this->ci->ForeColor = System::Drawing::Color::Green;
				 this->t1->BackColor = System::Drawing::Color::Green;
				 this->u2->BackColor = System::Drawing::Color::Green;
				 this->r3->BackColor = System::Drawing::Color::Green;
				 this->t4->BackColor = System::Drawing::Color::Green;
				 this->l5->BackColor = System::Drawing::Color::Green;
				 this->ee6->BackColor = System::Drawing::Color::Green;
				 
				 if (this->wo1->Text == "-----")
				 {
					 this->wo1->Text = this->textBox1->Text;
				 }
				 else if (this->wo2->Text == "-----")
				 {
					 this->wo2->Text = this->textBox1->Text;
				 }
				 else if (this->wo3->Text == "-----")
				 {
					 this->wo3->Text = this->textBox1->Text;
				 }
				 else if (this->wo4->Text == "-----")
				 {
					 this->wo4->Text = this->textBox1->Text;
				 }
				 else if (this->wo5->Text == "-----")
				 {
					 this->wo5->Text = this->textBox1->Text;
				 }
				 else if (this->wo6->Text == "-----")
				 {
					 this->wo6->Text = this->textBox1->Text;
				 }
				 else if (this->wo7->Text == "-----")
				 {
					 this->wo7->Text = this->textBox1->Text;
				 }
				 else if (this->wo8->Text == "-----")
				 {
					 this->wo8->Text = this->textBox1->Text;
				 }
				 else if (this->wo9->Text == "-----")
				 {
					 this->wo9->Text = this->textBox1->Text;
				 }
				 else if (this->wo10->Text == "-----")
				 {
					 this->wo10->Text = this->textBox1->Text;
				 }


				 this->textBox1->Text = String::Empty;
			 }
			 else if (word1 == "duck")
			 {
				 this->ci->Text = "Correct word!!";
				 this->ci->ForeColor = System::Drawing::Color::Green;
				 this->d10->BackColor = System::Drawing::Color::Green;
				 this->u10->BackColor = System::Drawing::Color::Green;
				 this->c10->BackColor = System::Drawing::Color::Green;
				 this->k10->BackColor = System::Drawing::Color::Green;

			     if (this->wo1->Text == "-----")
				 {
					 this->wo1->Text = this->textBox1->Text;
				 }
				 else if (this->wo2->Text == "-----")
				 {
					 this->wo2->Text = this->textBox1->Text;
				 }
				 else if (this->wo3->Text == "-----")
				 {
					 this->wo3->Text = this->textBox1->Text;
				 }
				 else if (this->wo4->Text == "-----")
				 {
					 this->wo4->Text = this->textBox1->Text;
				 }
				 else if (this->wo5->Text == "-----")
				 {
					 this->wo5->Text = this->textBox1->Text;
				 }
				 else if (this->wo6->Text == "-----")
				 {
					 this->wo6->Text = this->textBox1->Text;
				 }
				 else if (this->wo7->Text == "-----")
				 {
					 this->wo7->Text = this->textBox1->Text;
				 }
				 else if (this->wo8->Text == "-----")
				 {
					 this->wo8->Text = this->textBox1->Text;
				 }
				 else if (this->wo9->Text == "-----")
				 {
					 this->wo9->Text = this->textBox1->Text;
				 }
				 else if (this->wo10->Text == "-----")
				 {
					 this->wo10->Text = this->textBox1->Text;
				 }


				 this->textBox1->Text = String::Empty;
			 }
			 else if (word1 == "giraffe")
			 {
				 this->ci->Text = "Correct word!!";
				 this->ci->ForeColor = System::Drawing::Color::Green;
				 this->g3->BackColor = System::Drawing::Color::Green;
				 this->i4->BackColor = System::Drawing::Color::Green;
				 this->r5->BackColor = System::Drawing::Color::Green;
				 this->a6->BackColor = System::Drawing::Color::Green;
				 this->f7->BackColor = System::Drawing::Color::Green;
				 this->f8->BackColor = System::Drawing::Color::Green;
				 this->e9->BackColor = System::Drawing::Color::Green;

			     if (this->wo1->Text == "-----")
				 {
					 this->wo1->Text = this->textBox1->Text;
				 }
				 else if (this->wo2->Text == "-----")
				 {
					 this->wo2->Text = this->textBox1->Text;
				 }
				 else if (this->wo3->Text == "-----")
				 {
					 this->wo3->Text = this->textBox1->Text;
				 }
				 else if (this->wo4->Text == "-----")
				 {
					 this->wo4->Text = this->textBox1->Text;
				 }
				 else if (this->wo5->Text == "-----")
				 {
					 this->wo5->Text = this->textBox1->Text;
				 }
				 else if (this->wo6->Text == "-----")
				 {
					 this->wo6->Text = this->textBox1->Text;
				 }
				 else if (this->wo7->Text == "-----")
				 {
					 this->wo7->Text = this->textBox1->Text;
				 }
				 else if (this->wo8->Text == "-----")
				 {
					 this->wo8->Text = this->textBox1->Text;
				 }
				 else if (this->wo9->Text == "-----")
				 {
					 this->wo9->Text = this->textBox1->Text;
				 }
				 else if (this->wo10->Text == "-----")
				 {
					 this->wo10->Text = this->textBox1->Text;
				 }


				 this->textBox1->Text = String::Empty;
			 }
			 else if (word1 == "monkey")
			 {
				 this->ci->Text = "Correct word!!";
				 this->ci->ForeColor = System::Drawing::Color::Green;
				 this->m7->BackColor = System::Drawing::Color::Green;
				 this->oo7->BackColor = System::Drawing::Color::Green;
				 this->n7->BackColor = System::Drawing::Color::Green;
				 this->k7->BackColor = System::Drawing::Color::Green;
				 this->e7->BackColor = System::Drawing::Color::Green;
				 this->yy7->BackColor = System::Drawing::Color::Green;

				 if (this->wo1->Text == "-----")
				 {
					 this->wo1->Text = this->textBox1->Text;
				 }
				 else if (this->wo2->Text == "-----")
				 {
					 this->wo2->Text = this->textBox1->Text;
				 }
				 else if (this->wo3->Text == "-----")
				 {
					 this->wo3->Text = this->textBox1->Text;
				 }
				 else if (this->wo4->Text == "-----")
				 {
					 this->wo4->Text = this->textBox1->Text;
				 }
				 else if (this->wo5->Text == "-----")
				 {
					 this->wo5->Text = this->textBox1->Text;
				 }
				 else if (this->wo6->Text == "-----")
				 {
					 this->wo6->Text = this->textBox1->Text;
				 }
				 else if (this->wo7->Text == "-----")
				 {
					 this->wo7->Text = this->textBox1->Text;
				 }
				 else if (this->wo8->Text == "-----")
				 {
					 this->wo8->Text = this->textBox1->Text;
				 }
				 else if (this->wo9->Text == "-----")
				 {
					 this->wo9->Text = this->textBox1->Text;
				 }
				 else if (this->wo10->Text == "-----")
				 {
					 this->wo10->Text = this->textBox1->Text;
				 }


				 this->textBox1->Text = String::Empty;
				 
			 }
			 else if (word1 == "cat")
			 {
				 this->ci->Text = "Correct word!!";
				 this->ci->ForeColor = System::Drawing::Color::Green;
				 this->c2->BackColor = System::Drawing::Color::Green;
				 this->a3->BackColor = System::Drawing::Color::Green;
				 this->tt4->BackColor = System::Drawing::Color::Green;

				 if (this->wo1->Text == "-----")
				 {
					 this->wo1->Text = this->textBox1->Text;
				 }
				 else if (this->wo2->Text == "-----")
				 {
					 this->wo2->Text = this->textBox1->Text;
				 }
				 else if (this->wo3->Text == "-----")
				 {
					 this->wo3->Text = this->textBox1->Text;
				 }
				 else if (this->wo4->Text == "-----")
				 {
					 this->wo4->Text = this->textBox1->Text;
				 }
				 else if (this->wo5->Text == "-----")
				 {
					 this->wo5->Text = this->textBox1->Text;
				 }
				 else if (this->wo6->Text == "-----")
				 {
					 this->wo6->Text = this->textBox1->Text;
				 }
				 else if (this->wo7->Text == "-----")
				 {
					 this->wo7->Text = this->textBox1->Text;
				 }
				 else if (this->wo8->Text == "-----")
				 {
					 this->wo8->Text = this->textBox1->Text;
				 }
				 else if (this->wo9->Text == "-----")
				 {
					 this->wo9->Text = this->textBox1->Text;
				 }
				 else if (this->wo10->Text == "-----")
				 {
					 this->wo10->Text = this->textBox1->Text;
				 }


				 this->textBox1->Text = String::Empty;
			 }
			 else if (word1 == "ostrich")
			 {
				 this->ci->Text = "Correct word!!";
				 this->ci->ForeColor = System::Drawing::Color::Green;
				 this->o9->BackColor = System::Drawing::Color::Green;
				 this->s9->BackColor = System::Drawing::Color::Green;
				 this->t9->BackColor = System::Drawing::Color::Green;
				 this->r9->BackColor = System::Drawing::Color::Green;
				 this->i9->BackColor = System::Drawing::Color::Green;
				 this->c9->BackColor = System::Drawing::Color::Green;
				 this->hh9->BackColor = System::Drawing::Color::Green;

				 if (this->wo1->Text == "-----")
				 {
					 this->wo1->Text = this->textBox1->Text;
				 }
				 else if (this->wo2->Text == "-----")
				 {
					 this->wo2->Text = this->textBox1->Text;
				 }
				 else if (this->wo3->Text == "-----")
				 {
					 this->wo3->Text = this->textBox1->Text;
				 }
				 else if (this->wo4->Text == "-----")
				 {
					 this->wo4->Text = this->textBox1->Text;
				 }
				 else if (this->wo5->Text == "-----")
				 {
					 this->wo5->Text = this->textBox1->Text;
				 }
				 else if (this->wo6->Text == "-----")
				 {
					 this->wo6->Text = this->textBox1->Text;
				 }
				 else if (this->wo7->Text == "-----")
				 {
					 this->wo7->Text = this->textBox1->Text;
				 }
				 else if (this->wo8->Text == "-----")
				 {
					 this->wo8->Text = this->textBox1->Text;
				 }
				 else if (this->wo9->Text == "-----")
				 {
					 this->wo9->Text = this->textBox1->Text;
				 }
				 else if (this->wo10->Text == "-----")
				 {
					 this->wo10->Text = this->textBox1->Text;
				 }


				 this->textBox1->Text = String::Empty;
			 }
			 else if (word1 == "dog")
			 {
				 this->ci->Text = "Correct word!!";
				 this->ci->ForeColor = System::Drawing::Color::Green;
				 this->d2->BackColor = System::Drawing::Color::Green;
				 this->o3->BackColor = System::Drawing::Color::Green;
				 this->g4->BackColor = System::Drawing::Color::Green;

				 if (this->wo1->Text == "-----")
				 {
					 this->wo1->Text = this->textBox1->Text;
				 }
				 else if (this->wo2->Text == "-----")
				 {
					 this->wo2->Text = this->textBox1->Text;
				 }
				 else if (this->wo3->Text == "-----")
				 {
					 this->wo3->Text = this->textBox1->Text;
				 }
				 else if (this->wo4->Text == "-----")
				 {
					 this->wo4->Text = this->textBox1->Text;
				 }
				 else if (this->wo5->Text == "-----")
				 {
					 this->wo5->Text = this->textBox1->Text;
				 }
				 else if (this->wo6->Text == "-----")
				 {
					 this->wo6->Text = this->textBox1->Text;
				 }
				 else if (this->wo7->Text == "-----")
				 {
					 this->wo7->Text = this->textBox1->Text;
				 }
				 else if (this->wo8->Text == "-----")
				 {
					 this->wo8->Text = this->textBox1->Text;
				 }
				 else if (this->wo9->Text == "-----")
				 {
					 this->wo9->Text = this->textBox1->Text;
				 }
				 else if (this->wo10->Text == "-----")
				 {
					 this->wo10->Text = this->textBox1->Text;
				 }


				 this->textBox1->Text = String::Empty;
			 }
			 else if (word1 == "bunny")
			 {

				 this->ci->Text = "Correct word!!";
				 this->ci->ForeColor = System::Drawing::Color::Green;
				 this->b3->BackColor = System::Drawing::Color::Green;
				 this->u4->BackColor = System::Drawing::Color::Green;
				 this->n5->BackColor = System::Drawing::Color::Green;
				 this->n6->BackColor = System::Drawing::Color::Green;
				 this->y7->BackColor = System::Drawing::Color::Green;

				 if (this->wo1->Text == "-----")
				 {
					 this->wo1->Text = this->textBox1->Text;
				 }
				 else if (this->wo2->Text == "-----")
				 {
					 this->wo2->Text = this->textBox1->Text;
				 }
				 else if (this->wo3->Text == "-----")
				 {
					 this->wo3->Text = this->textBox1->Text;
				 }
				 else if (this->wo4->Text == "-----")
				 {
					 this->wo4->Text = this->textBox1->Text;
				 }
				 else if (this->wo5->Text == "-----")
				 {
					 this->wo5->Text = this->textBox1->Text;
				 }
				 else if (this->wo6->Text == "-----")
				 {
					 this->wo6->Text = this->textBox1->Text;
				 }
				 else if (this->wo7->Text == "-----")
				 {
					 this->wo7->Text = this->textBox1->Text;
				 }
				 else if (this->wo8->Text == "-----")
				 {
					 this->wo8->Text = this->textBox1->Text;
				 }
				 else if (this->wo9->Text == "-----")
				 {
					 this->wo9->Text = this->textBox1->Text;
				 }
				 else if (this->wo10->Text == "-----")
				 {
					 this->wo10->Text = this->textBox1->Text;
				 }


				 this->textBox1->Text = String::Empty;
			 }
			 else if (word1 == "mouse")
			 {
				 this->ci->Text = "Correct word!!";
				 this->ci->ForeColor = System::Drawing::Color::Green;
				 this->mm6->BackColor = System::Drawing::Color::Green;
				 this->o6->BackColor = System::Drawing::Color::Green;
				 this->u6->BackColor = System::Drawing::Color::Green;
				 this->s6->BackColor = System::Drawing::Color::Green;
				 this->e6->BackColor = System::Drawing::Color::Green;

				 if (this->wo1->Text == "-----")
				 {
					 this->wo1->Text = this->textBox1->Text;
				 }
				 else if (this->wo2->Text == "-----")
				 {
					 this->wo2->Text = this->textBox1->Text;
				 }
				 else if (this->wo3->Text == "-----")
				 {
					 this->wo3->Text = this->textBox1->Text;
				 }
				 else if (this->wo4->Text == "-----")
				 {
					 this->wo4->Text = this->textBox1->Text;
				 }
				 else if (this->wo5->Text == "-----")
				 {
					 this->wo5->Text = this->textBox1->Text;
				 }
				 else if (this->wo6->Text == "-----")
				 {
					 this->wo6->Text = this->textBox1->Text;
				 }
				 else if (this->wo7->Text == "-----")
				 {
					 this->wo7->Text = this->textBox1->Text;
				 }
				 else if (this->wo8->Text == "-----")
				 {
					 this->wo8->Text = this->textBox1->Text;
				 }
				 else if (this->wo9->Text == "-----")
				 {
					 this->wo9->Text = this->textBox1->Text;
				 }
				 else if (this->wo10->Text == "-----")
				 {
					 this->wo10->Text = this->textBox1->Text;
				 }


				 this->textBox1->Text = String::Empty;
			 }
			 else if (word1 == "fish")
			 {
				 this->ci->Text = "Correct word!!";
				 this->ci->ForeColor = System::Drawing::Color::Green;
				 this->ff1->BackColor = System::Drawing::Color::Green;
				 this->i1->BackColor = System::Drawing::Color::Green;
				 this->s1->BackColor = System::Drawing::Color::Green;
				 this->h1->BackColor = System::Drawing::Color::Green;

				 if (this->wo1->Text == "-----")
				 {
					 this->wo1->Text = this->textBox1->Text;
				 }
				 else if (this->wo2->Text == "-----")
				 {
					 this->wo2->Text = this->textBox1->Text;
				 }
				 else if (this->wo3->Text == "-----")
				 {
					 this->wo3->Text = this->textBox1->Text;
				 }
				 else if (this->wo4->Text == "-----")
				 {
					 this->wo4->Text = this->textBox1->Text;
				 }
				 else if (this->wo5->Text == "-----")
				 {
					 this->wo5->Text = this->textBox1->Text;
				 }
				 else if (this->wo6->Text == "-----")
				 {
					 this->wo6->Text = this->textBox1->Text;
				 }
				 else if (this->wo7->Text == "-----")
				 {
					 this->wo7->Text = this->textBox1->Text;
				 }
				 else if (this->wo8->Text == "-----")
				 {
					 this->wo8->Text = this->textBox1->Text;
				 }
				 else if (this->wo9->Text == "-----")
				 {
					 this->wo9->Text = this->textBox1->Text;
				 }
				 else if (this->wo10->Text == "-----")
				 {
					 this->wo10->Text = this->textBox1->Text;
				 }
				 

				 this->textBox1->Text = String::Empty;
			 }
			 else
			 {
				 this->ci->Text = "Incorrect word!!";
				 this->ci->ForeColor = System::Drawing::Color::Red;
			 }
			 if (this->wo10->Text != "-----")
			 {
				 jumpwon^ jw = gcnew jumpwon();
				 jw->Show();
			 }
}
private: System::Void pictureBox1_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void wo2_Click(System::Object^  sender, System::EventArgs^  e) {
}
};
}
